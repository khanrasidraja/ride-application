const express = require('express');
const router = express.Router();
const stripeController = require('../controllers/stripeController');

// Define your route endpoints and associate them with the respective controller functions
