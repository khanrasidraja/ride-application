// const SMTPClient = require('emailjs');

// const client = new SMTPClient({
//   user: 'your-username', // Replace with your SMTP username or email address
//   password: 'your-password', // Replace with your SMTP password or app password
//   host: 'smtp.your-email.com', // Replace with your SMTP host
//   ssl: true,
// });

// const message = {
//   text: 'I hope this works',
//   from: 'Your Name <username@your-email.com>', // Replace with your name and email address
//   to: 'Someone <someone@your-email.com>, Another <another@your-email.com>',
//   cc: 'Else <else@your-email.com>',
//   subject: 'Testing emailjs',
// };

// // send the message and get a callback with an error or details of the message that was sent
// client.send(message, (err, message) => {
//   console.log(err || message);
// });

// module.exports = { client, message };
